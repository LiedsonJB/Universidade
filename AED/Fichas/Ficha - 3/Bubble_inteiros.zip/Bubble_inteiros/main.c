#include "funcao.h"

int main(){
    system("color 4");

    int *v = NULL;
    int n;

    printf("Quantos elementos queres: ");
    scanf("%d", &n);

    if(n < 0)
        n *= -1;

    v = alocar(v, n);

    system("cls");
    system("color A");
    printf("Tentando alocar espaco!!!!!\nPor favor aguarde");
    sleep(2);
    system("cls");

    if(v != NULL){
        printf("Alocacao feita com sucesso!!!!\nPrime alguma tecla para continuar\n");

        system("pause");
        system("cls");

        ler(v, n);

        menu_inicial(v, n);
        free(v);


    }else{
        system("color 0");
        printf("\nErro 1: Impossivel alocar espaco");
        return -1;
    }

    return 0;
}
