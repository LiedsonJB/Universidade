#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <time.h>

int somaBV = 0; //var para somar os bilhetes vendidos
pthread_mutex_t mutex;//criar objeto mutex
char *filme[] = {"One Piece: Strong World", "One Piece Film: Z", "One piece: Red"};//meus filmes
int threads = 1;

typedef struct Filme{
    char *nome; //nome filme
    int NumBl; //numero de bilhtes disponiveis
    float preco; //preco dos filmes

}Filme;

Filme movies[3]; //vetor de estrutura para armazenar os filmes

void *compra(void *args){

    int pos = *(int *)args;//converter args para inteiro e colocar o valor na var pos
    int valor = movies[pos].NumBl;

    pthread_mutex_lock(&mutex);//bloquear uma mutex
        if(movies[pos].NumBl <= 0){
            printf("\n--------------------------------\n");
            printf("Tarefa %d\n", threads);
            printf("\nSem bilhetes para o filme: %s\n", movies[pos].nome);
            printf("\n--------------------------------\n");
            threads++;//incrementar tarfeas
            pthread_mutex_unlock(&mutex);//desbloquear uma mutex

            return  NULL;

        }else{
            printf("\n--------------------------------\n");
            printf("\nThread %d comprou um bilhete do filme %s\n", threads, movies[pos].nome);
            movies[pos].NumBl--;//descrementar numero de bilhetes disponiveis 
            printf("Numeros de bilhetes disponiveis para esse filme: %d", movies[pos].NumBl);
            printf("\n--------------------------------\n");
            somaBV++;//incrementar soma de bilhetes vendidos
            threads++;//incrementar tarefas
        }
    pthread_mutex_unlock(&mutex);//desbloquear uma mutex

    return NULL;
}

void filmesDeOnePiece(){
    for(int i=0; i<3; i++){
        movies[i].nome = (char *)malloc(sizeof(char)*strlen(filme[i]));//alocar espaco para os filmes
        strcpy(movies[i].nome, filme[i]);//copiar os filmes
        movies[i].NumBl = rand()%4; //gerar um numero aleatorio de 0 ate 3
        movies[i].preco = rand()%101; //preco de cada filme
    }
}

int main() {
    srand(time(NULL));//para nao rodar o mesmo numero toda vez que inicializar o programa 

    pthread_t tarefas[10];//meus objetos de tarefas
    pthread_mutex_init(&mutex, NULL);//inicializar mutex

    filmesDeOnePiece();//funcao para prencher o vetor de filmes

    for(int i=0; i<10; i++){
        int j = rand()%3; //numero aletorio de 0 ate 2
        
        pthread_create(&tarefas[i], NULL, compra, (void *)&j);//criar tarefas
    }

    for(int i=0;i<10;i++){
        pthread_join(tarefas[i], NULL);//esperar por termino das tarefas
    }

    printf("Foram vendidos um total de: %d\n", somaBV); //mostrar num de bilhetes vendidos
    pthread_mutex_destroy(&mutex);//destruir uma mutex

    return 0;
}